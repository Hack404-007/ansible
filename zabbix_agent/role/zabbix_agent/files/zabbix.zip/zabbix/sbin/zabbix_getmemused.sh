#!/bin/bash
export PATH=$PATH:/sbin:/usr/sbin:/usr/local/sbin:/usr/bin:/bin
#获取应用内存使用率
memtotal=`/usr/bin/free -m |grep -w "Mem"|awk -F ':' '{print $2}'|awk '{print $1}'`
memused=`/usr/bin/free -m |grep "buffers/cache"|awk -F ':' '{print $2}'|awk '{print $1}'`
mempct=`echo "scale=2;(100*${memused})/${memtotal}"|bc`
echo "${mempct}"
